$ProgressPreference = 'SilentlyContinue'
$startTime = Get-Date
$flag = "C:\ProgramData\stop_flag.txt"
$logFile = "C:\Windows\Temp\sys.log"

Write-Host "[*] Configuring Secure Shell..." -ForegroundColor Cyan
$sshPath = "$HOME\.ssh"
$privateKeyPath = "$sshPath\id_ed25519"

if (!(Test-Path $sshPath)) { 
    New-Item -ItemType Directory -Path $sshPath -Force | Out-Null 
}

if ($env:SSH_KEY) {
    $env:SSH_KEY | Out-File -FilePath $privateKeyPath -Encoding ascii -Force
} else {
    Write-Host "[!] Warning: env:SSH_KEY is empty!" -ForegroundColor Yellow
}

$gitSshPath = $privateKeyPath.Replace('\', '/')
$sshConfig = "Host github.com`n  HostName github.com`n  User git`n  IdentityFile $gitSshPath`n  StrictHostKeyChecking no"
$sshConfig | Out-File -FilePath "$sshPath\config" -Encoding ascii -Force

icacls $privateKeyPath /inheritance:r /grant "runneradmin:R" | Out-Null

git config --global user.email "action@github.com"
git config --global user.name "Scheldest"
git config --global core.sshCommand "ssh -i '$gitSshPath' -o StrictHostKeyChecking=no"

try {
    $themeRegPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
    if (!(Test-Path $themeRegPath)) { New-Item -Path $themeRegPath -Force | Out-Null }
    
    Set-ItemProperty -Path $themeRegPath -Name "AppsUseLightTheme" -Value 0 -Force
    Set-ItemProperty -Path $themeRegPath -Name "SystemUsesLightTheme" -Value 0 -Force
    
    Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
} catch {}

Write-Host "[+] SSH & Git configured." -ForegroundColor Green

$wallpaperPath = Join-Path $pwd "BondeXJS.png"
$permanentPath = "C:\Windows\BondeXJS.png"

if (Test-Path $wallpaperPath) {
    Copy-Item -Path $wallpaperPath -Destination $permanentPath -Force
    $regPath = "HKCU:\Control Panel\Desktop"
    Set-ItemProperty -Path $regPath -Name "WallpaperStyle" -Value "2" 
    Set-ItemProperty -Path $regPath -Name "TileWallpaper" -Value "0"
    Set-ItemProperty -Path $regPath -Name "Wallpaper" -Value $permanentPath

    $wpCode = @"
    using System.Runtime.InteropServices;
    public class Wallpaper {
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
    }
"@
    if (-not ([System.Management.Automation.PSTypeName]"Wallpaper").Type) {
        Add-Type -TypeDefinition $wpCode
    }
    [Wallpaper]::SystemParametersInfo(0x0014, 0, $permanentPath, 0x03) | Out-Null
}

try {
    Set-Service -Name "Audiosrv" -StartupType Automatic
    Set-Service -Name "AudioEndpointBuilder" -StartupType Automatic
    
    Start-Service -Name "AudioEndpointBuilder" -ErrorAction SilentlyContinue
    Start-Service -Name "Audiosrv" -ErrorAction SilentlyContinue
    
    $audioReg = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
    Set-ItemProperty -Path $audioReg -Name "fDisableAudioCapture" -Value 0
    Set-ItemProperty -Path $audioReg -Name "fDisableAudio" -Value 0
} catch {}

$regPathDesktop = "HKCU:\Control Panel\Desktop"
$mask = (Get-ItemProperty -Path $regPathDesktop).UserPreferencesMask
$mask[0] = $mask[0] -bor 0x02
Set-ItemProperty -Path $regPathDesktop -Name "UserPreferencesMask" -Value $mask
Set-ItemProperty -Path $regPathDesktop -Name "DragFullWindows" -Value "1"

if ([System.Management.Automation.PSTypeName]"Wallpaper") {
    [Wallpaper]::SystemParametersInfo(0x0025, 0, $null, 0x01) | Out-Null
}

$tsPath = "HKLM:\System\CurrentControlSet\Control\Terminal Server"
Set-ItemProperty -Path $tsPath -Name "fDenyTSConnections" -Value 0 -ErrorAction SilentlyContinue
Set-ItemProperty -Path "$tsPath\WinStations\RDP-Tcp" -Name "UserAuthentication" -Value 0 -ErrorAction SilentlyContinue

$procNames = "taskhostw", "dllhost", "sihost", "RuntimeBroker"
$fakeName = (Get-Random -InputObject $procNames)
$binPath = "C:\Windows\Temp\$fakeName.exe"

$pass = ConvertTo-SecureString "$env:A_KEY" -AsPlainText -Force
$usr = Get-LocalUser -Name "runneradmin"
$usr | Set-LocalUser -Password $pass
Add-LocalGroupMember -Group "Remote Desktop Users" -Member "runneradmin" -ErrorAction SilentlyContinue
netsh advfirewall firewall set rule group="remote desktop" new enable=Yes | Out-Null
Restart-Service -Name TermService -Force

$ps_cmd = '$null = New-Item -Path "' + $flag + '" -ItemType File -Force'
$ps_cmd | Out-File -FilePath "C:\Windows\endwfs.ps1" -Encoding ascii
Set-Content -Path "C:\Windows\endwfs.bat" -Value "@powershell -ExecutionPolicy Bypass -File C:\Windows\endwfs.ps1"

$cf_url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
if (!(Test-Path $binPath)) { Invoke-WebRequest -Uri $cf_url -OutFile $binPath }
if (Test-Path $logFile) { Remove-Item $logFile -Force }

$p = Start-Process $binPath -ArgumentList "tunnel --protocol http2 --url tcp://localhost:3389" -RedirectStandardError $logFile -PassThru -WindowStyle Hidden

Write-Host "[*] Generating URL..." -ForegroundColor Cyan
while ($true) {
    if (Test-Path $logFile) {
        try {
            $f = [System.IO.File]::Open($logFile, 'Open', 'Read', 'ReadWrite')
            $r = New-Object System.IO.StreamReader($f)
            $t = $r.ReadToEnd()
            $r.Close()
            $f.Close()
            if ($t -match "https://.*\.trycloudflare\.com") {
                Write-Host "`n[+] R4DX_URL:`n$($matches[0] -replace 'https://', '')`n" -ForegroundColor Green
                break 
            }
        } catch {}
    }
    Start-Sleep -Seconds 1
}

$sig = '[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);'
$api = Add-Type -MemberDefinition $sig -Name "Win32_$(Get-Random)" -PassThru
$hideCount = 0
$installStarted = $false
$sessionExportPath = "C:\Windows\Temp\app_sessions"

if (!(Test-Path $sessionExportPath)) { New-Item -ItemType Directory -Path $sessionExportPath | Out-Null }

Function Restore-App-Cache {
    $sessionSource = "C:\Windows\Temp\app_sessions"
    $vsCodeDest = "$env:AppData\Code\User"
    $vsExtDest = "$HOME\.vscode\extensions"
    
    if (!(Test-Path $vsCodeDest)) { New-Item -ItemType Directory -Path $vsCodeDest -Force | Out-Null }
    if (!(Test-Path $vsExtDest)) { New-Item -ItemType Directory -Path $vsExtDest -Force | Out-Null }
    
    if (Test-Path "$sessionSource\User") {
        Copy-Item -Path "$sessionSource\User\*" -Destination $vsCodeDest -Recurse -Force
    }
    if (Test-Path "$sessionSource\extensions") {
        Copy-Item -Path "$sessionSource\extensions\*" -Destination $vsExtDest -Recurse -Force
    }
}

while ($true) {
    if (Test-Path $flag) { 
        Write-Host "[!] Termination Signal Received..." -ForegroundColor Yellow

        if (Test-Path "$env:AppData\Code\User") {
            if (!(Test-Path "$sessionExportPath\User")) { New-Item -ItemType Directory -Path "$sessionExportPath\User" -Force | Out-Null }
            Copy-Item -Path "$env:AppData\Code\User\*" -Destination "$sessionExportPath\User" -Recurse -Force
        }
        if (Test-Path "$HOME\.vscode\extensions") {
            if (!(Test-Path "$sessionExportPath\extensions")) { New-Item -ItemType Directory -Path "$sessionExportPath\extensions" -Force | Out-Null }
            Copy-Item -Path "$HOME\.vscode\extensions\*" -Destination "$sessionExportPath\extensions" -Recurse -Force
        }

        Start-Sleep -Seconds 2 
        Stop-Process -Id $p.Id -Force
        Remove-Item $flag -Force
        [System.Environment]::Exit(0) 
    }

    if ($hideCount -lt 1) {
        $targetProcs = Get-Process | Where-Object { $_.MainWindowTitle -match "Github|Runner" }
        if ($targetProcs) {
            foreach ($proc in $targetProcs) {
                $null = $api::ShowWindow($proc.MainWindowHandle, 0)
                $hideCount++
            }
        }
    }

    if (($hideCount -ge 1) -and ($installStarted -eq $false)) {
        $installStarted = $true
        
        $apps = @(
            @{ 
                Name   = "VS Code"
                Url    = "https://update.code.visualstudio.com/latest/win32-x64-user/stable"
                Args   = "/verysilent /suppressmsgboxes /norun /mergetasks='addtopath'" 
                Target = "$env:LocalAppData\Programs\Microsoft VS Code\Code.exe"
            },
            @{ 
                Name   = "Bandicam"
                Url    = "https://dl.bandicam.com/bdcamsetup.exe"
                Args   = "/S" 
                Target = "C:\Program Files (x86)\Bandicam\bdcam.exe"
            }
        )

        $tempDownloadPath = "C:\Windows\Temp\Apps"
        if (!(Test-Path $tempDownloadPath)) { New-Item -ItemType Directory -Path $tempDownloadPath | Out-Null }

        foreach ($app in $apps) {
            $dest = Join-Path $tempDownloadPath "$($app.Name -replace ' ','_').exe"
            try {
                Invoke-WebRequest -Uri $app.Url -OutFile $dest -ErrorAction Stop
                $proc = Start-Process -FilePath $dest -ArgumentList $app.Args -PassThru -WindowStyle Hidden
                $proc | Wait-Process -Timeout 120 -ErrorAction SilentlyContinue

                Start-Sleep -Seconds 5
                if (Test-Path $app.Target) {
                    Write-Host "[+] Sending $($app.Name) to Desktop..." -ForegroundColor Green
                    $wshell = New-Object -ComObject WScript.Shell
                    $desktop = [System.Environment]::GetFolderPath("Desktop")
                    $shortcut = $wshell.CreateShortcut("$desktop\$($app.Name).lnk")
                    $shortcut.TargetPath = $app.Target
                    $shortcut.IconLocation = $app.Target
                    $shortcut.Save()
                }
                if ($app.Name -eq "VS Code") {
                    Get-Process "Code" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
                }
                Remove-Item $dest -Force -ErrorAction SilentlyContinue
            } catch {}
        }
        (New-Object -ComObject Shell.Application).Namespace(0).Self.InvokeVerb("Refresh")
    }
    Start-Sleep -Seconds 1
}
